# Literature Review Export

Generated: 2025-07-31 20:55:59

## Contents

- `data/`: Extracted data in CSV, JSON, and Excel formats
- `figures/`: Visualization plots
- `summary_report.json`: Summary statistics
- `metadata.json`: Export metadata and configuration
- `logs/`: Processing logs and database

## Summary Statistics

- Total papers: 250
- Date range: 2018-2024
- Sources: arxiv

## Data Dictionary

### Main Fields
- `title`: Paper title
- `authors`: Semi-colon separated author names
- `year`: Publication year
- `abstract`: Paper abstract
- `doi`: Digital Object Identifier
- `url`: Paper URL
- `source_db`: Database source

### Extracted Fields
- `venue_type`: Type of publication venue
- `game_type`: Type of wargame
- `open_ended`: Whether game allows open-ended moves (yes/no)
- `quantitative`: Whether game tracks numeric scores (yes/no)
- `llm_family`: LLM model family used
- `llm_role`: Role of LLM (player/generator/analyst)
- `eval_metrics`: Evaluation metrics used
- `failure_modes`: Detected failure modes (pipe-separated)
- `awscale`: AWScale rating (1-5)
- `code_release`: GitHub URL or "none"

## Citation

If you use this data, please cite:
[Add citation information here]
